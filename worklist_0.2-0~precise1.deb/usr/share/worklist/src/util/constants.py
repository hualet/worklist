import os 

DATA_PATH = os.path.abspath(os.path.expanduser('~/.worklist/data'))
PID_PATH = os.path.join(DATA_PATH, 'worklist.pid')
