import os 

DATA_PATH = os.path.abspath(os.path.expanduser('~/.worklist/data'))

